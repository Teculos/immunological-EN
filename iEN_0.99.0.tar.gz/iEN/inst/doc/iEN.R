### R code from vignette source 'iEN.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: c1
###################################################
library(iEN)
install.packages("caret", repos='http://cran.us.r-project.org')
library(caret)

data(test_data)
alphaGrid <- seq(0,1, length.out=2)
phiGrid <- exp(seq(log(1),log(10), length.out=2))
nlambda <- 3
lambdas=NULL
ncores <- 2
eval <- "RSS" 
family <- "gaussian"
intercept <- TRUE
standardize <- TRUE
center <- TRUE

#define 10-fold cross-validation folds
temp.folds <- createFolds(unique(foldid),k=10)
folds <- vector()
for(k in seq(length(temp.folds))){
	folds[which(foldid %in% temp.folds[[k]])] <- k
}

model <- cv_iEN(X, Y, folds, alphaGrid, phiGrid, nlambda, lambdas, priors, ncores, eval, family, intercept, standardize, center)
Y.hat <- model@cv.preds
print(model)

plot(Y,Y.hat, ylab ="Predicted Gestational Age", xlab="Actual Gestational Age", cex=1.5, pch=20)
abline(fit <- lm(Y ~ Y.hat,), col='red')
legend("bottomright", bty="n", legend=paste("R2 is",  format(summary(fit)$adj.r.squared, digits=4)))


